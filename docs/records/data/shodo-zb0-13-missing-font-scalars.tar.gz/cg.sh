#!/bin/bash
# usage: cg.sh <label> <case> <n>
out=$(valgrind --tool=callgrind --callgrind-out-file=/dev/null ./probe-$1 loop $2 $3 2>&1 | grep -E "Collected" | awk '{print $4}' | tr -d ,)
echo "$1 $2 $3 $out"
