shodo-zb0.13 missing-font scalar measurements.
Labels: base f82e873 (probe only), new 96c6784. rustc 1.96.0, valgrind 3.25.1, release profile.
digest-*.jsonl: `missing_font_scalars digest` output per label (identical).
alloc-*.jsonl: `missing_font_scalars alloc` built with --features allocation-counting.
cg.txt: `cg.sh <label> <case> <n>` = callgrind total Ir of `loop <case> <n>`; per build = (n=10 - n=0)/10.
time-<label>-<batch>-*.jsonl: `taskset -c 10 missing_font_scalars time`, interleaved base,new,new,base per batch.
