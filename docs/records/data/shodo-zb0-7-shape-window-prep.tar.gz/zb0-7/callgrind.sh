#!/usr/bin/env bash
# Per-build instruction counts: (Ir(n=N) - Ir(n=0)) / N for each label and case.
set -euo pipefail
cd "$(dirname "$0")"
N=${N:-10}
mkdir -p cg
cases="latin-single latin-split16 arabic-single arabic-split16 cjk-upright-vorg-single cjk-upright-vorg-split16 cjk-upright-novorg-single cjk-upright-novorg-split16 ruby-base-split6"
ir() {
  valgrind --tool=callgrind --callgrind-out-file="cg/$1.$2.$3.out" "./$1" loop "$2" "$3" 2>&1 \
    | sed -n 's/.*Collected : \([0-9]*\).*/\1/p'
}
for label in "$@"; do
  for case in $cases; do
    zero=$(ir "$label" "$case" 0)
    full=$(ir "$label" "$case" "$N")
    echo "$label $case $(( (full - zero) / N ))"
  done
done
