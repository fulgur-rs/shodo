#!/usr/bin/env bash
# Build and archive the probe for one source state: snap.sh <label>
set -euo pipefail
cd "$(dirname "$0")/../../.."
out=target/performance-artifacts/zb0-7
label=$1
cargo build --locked --release -p shodo-bench --example shape_window_prep
cp target/release/examples/shape_window_prep "$out/$label"
cargo build --locked --release -p shodo-bench --features allocation-counting --example shape_window_prep
cp target/release/examples/shape_window_prep "$out/$label-alloc"
"$out/$label" digest > "$out/$label.digest"
"$out/$label-alloc" alloc > "$out/$label.alloc"
git rev-parse HEAD > "$out/$label.rev"
git diff HEAD > "$out/$label.patch"
sha256sum "$out/$label" "$out/$label-alloc" > "$out/$label.sha256"
