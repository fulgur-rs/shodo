#!/usr/bin/env bash
# DHAT totals for 10 builds per case (font load included, identical across labels).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p dhat
for label in base ctx prep; do
  for case in latin-single latin-split16 arabic-split16 cjk-upright-vorg-split16 cjk-upright-novorg-split16 ruby-base-split6; do
    total=$(valgrind --tool=dhat --dhat-out-file="dhat/$label.$case.json" "./$label" loop "$case" 10 2>&1 \
      | sed -n 's/.*Total: *\(.*\)/\1/p')
    echo "$label $case $total"
  done
done
