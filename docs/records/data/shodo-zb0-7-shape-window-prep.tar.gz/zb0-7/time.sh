#!/usr/bin/env bash
# Interleaved wall-clock runs pinned to one CPU: base ctx prep prep ctx base.
set -euo pipefail
cd "$(dirname "$0")"
cpu=${CPU:-10}
: > time.jsonl
for label in base ctx prep prep ctx base; do
  for case in latin-split16 arabic-split16 cjk-upright-vorg-split16 cjk-upright-novorg-split16 ruby-base-split6 latin-single cjk-upright-novorg-single; do
    taskset -c "$cpu" "./$label" time "$case" | sed "s/^{/{\"label\":\"$label\",/" >> time.jsonl
  done
done
python3 - <<'EOF'
import json, collections
rows = collections.defaultdict(list)
for r in map(json.loads, open('time.jsonl')):
    rows[(r['case'], r['label'])].append(r['measurement']['median_ns'] / 1e6)
cases = list(dict.fromkeys(c for c, _ in rows))
print('| case | base (ms) | ctx (ms) | prep (ms) |')
print('| --- | ---: | ---: | ---: |')
for c in cases:
    print(f"| {c} | " + " | ".join(' / '.join(f'{v:.3f}' for v in rows[(c, l)]) for l in ('base', 'ctx', 'prep')) + " |")
EOF
