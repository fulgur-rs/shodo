import json, sys, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def load(f): return {r['case']: r for r in map(json.loads, open(f))}
a, b = load(sys.argv[1] + '.alloc'), load(sys.argv[2] + '.alloc')
for k in a:
    ma, mb = a[k]['measurement'], b[k]['measurement']
    assert a[k]['sha256'] == b[k]['sha256'], k
    assert a[k]['warnings'] == b[k]['warnings'], k
    print(f"| {k} | {ma['calls']:,} → {mb['calls']:,} | {ma['allocated_bytes']:,} → {mb['allocated_bytes']:,} "
          f"| {ma['live_bytes']-ma['start_live_bytes']:,} → {mb['live_bytes']-mb['start_live_bytes']:,} "
          f"| {ma['peak_extra_bytes']:,} → {mb['peak_extra_bytes']:,} |")
